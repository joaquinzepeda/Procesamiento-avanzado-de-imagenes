Se debe subir el archivo imagenes_tarea4_2022.zip con las imagenes
y luego ejecutar todas las celdas.
 